package ru.tinkoff.behavior.command.command;

public interface CommandInterface {

    public void execute();
    public void cancel();

}
