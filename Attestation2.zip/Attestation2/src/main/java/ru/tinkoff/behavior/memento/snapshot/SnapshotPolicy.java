package ru.tinkoff.behavior.memento.snapshot;

public interface SnapshotPolicy {
    public String getFIO();
    public boolean isNotification();
}
