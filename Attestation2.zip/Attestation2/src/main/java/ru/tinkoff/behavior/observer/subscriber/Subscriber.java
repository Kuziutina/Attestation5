package ru.tinkoff.behavior.observer.subscriber;

public interface Subscriber {
    public void doLogic(String policy);
}
