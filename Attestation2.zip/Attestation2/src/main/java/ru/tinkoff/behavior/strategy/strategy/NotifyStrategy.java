package ru.tinkoff.behavior.strategy.strategy;

public interface NotifyStrategy {
    void notify(String text);
}
