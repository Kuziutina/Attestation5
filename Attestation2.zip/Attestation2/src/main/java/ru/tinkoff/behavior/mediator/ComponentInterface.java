package ru.tinkoff.behavior.mediator;

public interface ComponentInterface {
}
