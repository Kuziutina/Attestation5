package ru.tinkoff.behavior.observer.core;

public class TaskCreator {

    public void createTask(String policy) {
        System.out.println("create task in system for policy " + policy);
    }
}
