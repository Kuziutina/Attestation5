package ru.tinkoff.behavior.mediator;

public interface MediatorInterface {
    public void notify(ComponentInterface component);
}
