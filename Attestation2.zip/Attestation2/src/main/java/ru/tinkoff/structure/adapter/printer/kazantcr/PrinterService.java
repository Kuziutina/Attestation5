package ru.tinkoff.structure.adapter.printer.kazantcr;

public interface PrinterService {

    boolean print(byte[] text);

}
