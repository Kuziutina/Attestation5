package ru.tinkoff.structure.proxy.createdocument;

public interface CreateDocumentServiceInterface {

    public void createPolicy(long id, String document);

}
