package ru.tinkoff.structure.decorator.sender;

public interface SenderInterface {
    void send(String text);
}
