package ru.tinkoff.structure.fasad.imagestorage;

public class ImageStorage {

    public String getImage(String title) {
        return "Печать.img";
    }
}
