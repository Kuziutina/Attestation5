package ru.tinkoff.structure.adapter.printer.vodniy;

public interface PrinterService {

    void print(String text);

}
