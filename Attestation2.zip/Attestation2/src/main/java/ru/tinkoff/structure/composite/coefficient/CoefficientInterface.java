package ru.tinkoff.structure.composite.coefficient;

import java.math.BigDecimal;

public interface CoefficientInterface {

    public BigDecimal rate();
}
