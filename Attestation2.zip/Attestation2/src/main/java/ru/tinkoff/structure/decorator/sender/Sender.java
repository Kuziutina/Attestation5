package ru.tinkoff.structure.decorator.sender;

public class Sender implements SenderInterface {

    public void send(String string) {

    }
}
