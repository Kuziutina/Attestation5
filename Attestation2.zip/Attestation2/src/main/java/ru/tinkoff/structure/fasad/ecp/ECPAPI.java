package ru.tinkoff.structure.fasad.ecp;

public class ECPAPI {

    public boolean sighDocument(String document) {
        System.out.println("Документ подписан ЭЦП");
        return true;
    }
}
