package ru.tinkoff.structure.bridge.sender;

public interface SenderInterface {

    public void sendPolicy(String document);
}
