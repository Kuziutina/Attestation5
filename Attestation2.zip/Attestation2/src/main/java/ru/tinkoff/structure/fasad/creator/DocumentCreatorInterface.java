package ru.tinkoff.structure.fasad.creator;

public interface DocumentCreatorInterface {

    public String createDocument();
    public String createInstruction();
}
