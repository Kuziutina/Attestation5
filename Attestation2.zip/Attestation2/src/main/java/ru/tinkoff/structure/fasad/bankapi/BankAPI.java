package ru.tinkoff.structure.fasad.bankapi;

public class BankAPI {
    public String getBankInfo() {
        return "BIC 83695893, name AO Bank";
    }
}
