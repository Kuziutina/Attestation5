package ru.tinkoff.create.factory.sender;

public interface PolicyDocumentSender {
    public void send(String policy);
}
