package ru.tinkoff.create.abstractfactory;

public interface PolicyDocumentSender {
    public void send(String policy);
}
