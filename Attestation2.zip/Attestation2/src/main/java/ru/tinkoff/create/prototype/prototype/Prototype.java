package ru.tinkoff.create.prototype.prototype;

public interface Prototype {
    public Prototype clone();
}
